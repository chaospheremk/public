> **Note for external readers**: This file documents internal Claude Code
> session conventions used by the maintainer. References to `../bugs.md`,
> `../decisions.md`, `../key-facts.md`, and `../issues.md` point to a private
> developer notebook that lives outside this repository; those paths do not
> resolve in a fresh clone. If you are contributing, see
> [CONTRIBUTING.md](CONTRIBUTING.md) instead.

# Code Session — `AD Permissions Analyzer`

## Context

This is the code repository for the `AD Permissions Analyzer` vault project.
Vault memory files are one level up in the parent directory:

- ../bugs.md        — known issues and solutions; check before debugging
- ../decisions.md   — decisions made; check before proposing changes
- ../key-facts.md   — project configuration reference
- ../issues.md      — work log

The vault session that manages planning and note-taking runs from the
vault root. This code session runs from this directory only.

The implementation specification has been captured at `docs/AD-Permissions-Analyzer-Plan.md`. Refine and section-break it during the planning phase before implementing.

## On Startup

1. Read ../decisions.md
2. Read ../bugs.md
3. Read ../key-facts.md
4. Read docs/AD-Permissions-Analyzer-Plan.md (implementation spec)

## Memory Protocols

**During the session, watch for:**

- Configuration patterns, parameter conventions, or environment facts worth keeping as reference — prompt to add to ../key-facts.md
- Learnings that are broadly reusable beyond this project — flag them so the vault session can promote them to resource notes
- Decisions being made conversationally that haven't been logged — prompt to add to ../decisions.md before the session ends

Before proposing a technical approach: read ../decisions.md
Before debugging: read ../bugs.md
After fixing a bug: append to ../bugs.md using the standard format
After making a technical decision: append to ../decisions.md as an ADR
After completing a work block: append to ../issues.md
If an entry represents broadly reusable knowledge: add `<!-- promote-candidate -->` so vault:promote finds it

## Vault Memory Writes

When editing parent vault files (`..\bugs.md`, `..\decisions.md`, `..\key-facts.md`, `..\issues.md`), use Edit/Write only — never MCPVault write tools (`mcp__secondbrain__write_note`, `patch_note`, `update_frontmatter`) — so vault-level hooks fire (`post-edit-write.ps1` and `validate-obsidian-syntax.ps1`). The `obsidian-markdown` skill (user-level) auto-triggers and enforces wikilink/callout/properties syntax. The `vault-conventions` skill (user-level) restates the MCP-read / Edit-Write-write contract for this code session.

## Memory Boundaries

Vault memory files (../bugs.md, ../decisions.md, ../key-facts.md, ../issues.md):
- Decisions, bugs, key facts, work log entries
- Anything the vault session or future sessions need
- Anything that might be promoted to a resource note

Serena memories (.serena/memories/):
- Code structure discovered via onboarding (module layout, public API surface)
- Build/test commands and environment setup notes
- Session continuity ("in progress" context for multi-session work)
- Code-session-only — the vault session never reads these

## Serena Tools

- Before modifying a public function signature: use `find_referencing_symbols` to identify all callers
- For cross-file renames: use `rename_symbol` instead of manual find-and-replace
- For single-function edits: prefer `replace_symbol_body` over full-file Edit
- For adding adjacent functions: use `insert_after_symbol` or `insert_before_symbol`
- Fallback: if Serena cannot find the symbol (syntax errors, unparseable file), use Edit
- Before writing code after a research phase: use `think_about_collected_information`
- During multi-step implementations: use `think_about_task_adherence` after each step
- Before reporting completion: use `think_about_whether_you_are_done`

## Session Handoff

Before ending a code session:
1. Ensure all bug fixes are logged in ../bugs.md
2. Ensure all decisions are logged in ../decisions.md
3. Ensure work completed is logged in ../issues.md
4. Report a one-paragraph summary of what changed

## Rules

- No real IDs, hostnames, credentials, or org-identifying content — ever
- All parameters use placeholders: `<tenant-id>` `<subscription-id>` etc.
- Never modify files outside this code/ folder except the four memory files
  (../bugs.md, ../decisions.md, ../key-facts.md, ../issues.md)
- The `powershell-standards` and `graph-api-powershell` skills trigger
  automatically when writing relevant code — no manual reads needed
- Read `../../../_meta/security.md` for full sanitization rules when needed

## GitHub

This folder is its own git repository.
Push directly to this project's GitHub remote.
Do not use the vault's 50-Outputs/ for this project's code.
Trunk-based: branch per PR from `main`, delete after merge. Never commit directly to `main`.
Pre-commit hooks must be installed: `pip install pre-commit && pre-commit install`
