#Requires -Version 7.0

<#
.SYNOPSIS
    Bootstrap loader for the AD Permissions Analyzer.

.DESCRIPTION
    Invokes the core implementation script which loads the
    System.DirectoryServices.Protocols assembly at runtime before dot-sourcing
    the lib files that depend on SDP types. PowerShell 7 resolves type literals
    at file-parse time, so the assembly must be present in the AppDomain before
    any file containing SDP type references is parsed. The core script achieves
    this with Add-Type before its dot-source statements.

    This wrapper exists so the user-facing entry point keeps its original name
    while the implementation lives in Invoke-ADPermissionAnalysis-Core.ps1.

    All parameters are forwarded verbatim via @args. See
    Invoke-ADPermissionAnalysis-Core.ps1 for full parameter documentation.

.EXAMPLE
    .\Invoke-ADPermissionAnalysis.ps1 -OutputDirectory C:\AdPermAudit

.EXAMPLE
    $params = @{
        Domain                = '<domain.fqdn>'
        Server                = '<dc-fqdn>'
        OutputDirectory       = 'C:\AdPermAudit'
        ThreadCount           = 8
        IncludeNamingContexts = @('Domain', 'Configuration')
    }
    .\Invoke-ADPermissionAnalysis.ps1 @params
#>

& "$PSScriptRoot\Invoke-ADPermissionAnalysis-Core.ps1" @args
exit $LASTEXITCODE

